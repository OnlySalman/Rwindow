from django.apps import AppConfig


class PollsappConfig(AppConfig):
    name = 'pollsApp'
