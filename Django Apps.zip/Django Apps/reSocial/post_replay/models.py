from django.db import models
from django.contrib.auth.models import User
from Blog.models import post

class pReplay(models.Model):
    uid = models.ForeignKey(User, on_delete=models.CASCADE)
    posted = models.ForeignKey(post, on_delete=models.CASCADE)
    content_replay = models.TextField()
    date_posted_replay = models.DateTimeField(auto_now_add=True)
