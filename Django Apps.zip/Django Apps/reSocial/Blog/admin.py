from django.contrib import admin
from .models import post

admin.site.register(post)
