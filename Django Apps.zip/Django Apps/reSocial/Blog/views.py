from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.views.generic import (
                                  ListView,
                                  DetailView,
                                  CreateView,
                                  UpdateView,
                                  DeleteView
                                  )
from .models import post
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from post_replay.models import pReplay
from django.contrib.auth.models import User

@login_required
def Friends_profile(request, username):
    profile_user = User.objects.get(username=username)
    context = {
        'profile_friend': profile_user,
        'title': "Friends",
    }
    return render(request, 'Blog/profile_friends.html', context)

@login_required
def home(request):
    uid = request.user.id
    # posts = post.objects.raw('SELECT * FROM Blog_post WHERE author_id = %s', [1])

    ##### Problem! #####:
    # There is no considration for the current User
    # posts = post.objects.raw('SELECT * FROM Blog_post WHERE author_id =%s  AND in (''SELECT uFrom_id FROM friends_Frinds WHERE rType==2'')', [uid])
    # posts = post.objects.raw('SELECT * FROM Blog_post WHERE author_id =%s AND Title in ("User","us","Users")', [uid])
    # THE FIRST PART IS TO RETERIVE HIS OWN POST
    # THE SECOND PART IS TO RETERIVE HIS FRIENDS POST
    posts = post.objects.raw('SELECT * FROM Blog_post LEFT JOIN post_replay_pReplay  ON Blog_post.id = post_replay_pReplay.posted_id WHERE author_id =%s OR author_id IN ('' SELECT uFrom_id FROM friends_Frinds WHERE uTo_id =%s AND rType=2 UNION SELECT uTo_id FROM friends_Frinds WHERE uFrom_id =%s '') ORDER BY  date_posted DESC',(uid, uid, uid))
    # replay = pReplay.objects.raw('SELECT * FROM post_replay_pReplay WHERE uid_id =%s OR uid_id IN ('' SELECT uFrom_id FROM friends_Frinds WHERE uTo_id =%s AND rType=2 '') ORDER BY  date_posted_replay DESC',(uid, uid))
    # replay = pReplay.objects.all()
    class replayPost(object):
        """docstring for replayPost."""

        def __init__(self,id,contentReplay, data):
            self.id = id
            self.contentReplay = contentReplay
            self.data = data

    class Content:
        def __init__(self,id , title, content, author, date_posted):
            self.id = id
            self.title = title
            self.content = content
            self.author = author
            self.date_posted = date_posted
            self.replayPost = []
            # self.rep = []
            # self.data_posted_replay = []
        # def addReplay(self, content):
        #     self.replayPost.append(content)
        # def addReplay(self, rep):
        #     self.rep.append(rep)
        #
        # def addReplay_posted(self, data_posted_replay):
        #     self.data_posted_replay.append(data_posted_replay)

    my_list = []
    counted = []
    handler = -1
    for posted in posts:
        uid = posted.id
        if uid not in counted:
            y = Content(posted.id,posted.title,posted.content,posted.author, posted.date_posted)
            if posted.content_replay != None:
                y.replayPost.append(replayPost(posted.id ,posted.content_replay, posted.date_posted_replay))
            # y.addReplay(posted.content_replay)
            # y.addReplay_posted(posted.date_posted_replay)
            counted.append(posted.id)
            my_list.append(y)
            # my_list[handler].replayPost.append(replayPost(posted.id ,posted.content_replay))
        else:
            for i in range(len(my_list)):
                if uid == my_list[i].id:
                    handler = i
                    break
            my_list[handler].replayPost.append(replayPost(posted.id ,posted.content_replay, posted.date_posted_replay))
            # my_list[handler].addReplay_posted(posted.date_posted_replay)
            # return HttpResponse(my_list[0].rep[0])
            # my_list.append(Content[my_list.id].addReplay(my_list[Content.id],posted.content_replay))
        # else:
            # my_list.append(my_list[posted.id].addReplay(my_list[Content.id],posted.content_replay))

    # x = " "
    # for i in range(len(my_list)):
    #          x += " id " + str(my_list[i].author) + " Title " + my_list[i].title
    #          for r in my_list[i].rep:
    #              x+= " His action from other users is " + str(r)
    #          x += "<br>"
    # return HttpResponse(x)
    context = {
        'posts': my_list,
        'title': "Home",
        # 'replay': replay
    }
    return render(request, 'Blog/home.html', context)

# class PostListView(ListView):
#     model = post
#     template_name = 'Blog/home.html'
#     context_object_name = 'posts'
#     ordering = ['-date_posted']

# Required get_absulte_url
# the name is givin such that no dirct intraction with the form template is done.
class PostCreateView(LoginRequiredMixin, CreateView):
    model = post
    fields = ['title', 'content']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

class PostUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = post
    fields = ['title', 'content']

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

    # So no user can update the post of otheruser
    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            return True
        return False


class PostDetailView(DetailView):
    model = post
    template_name = 'Blog/Detail.html'

class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin , DeleteView):
    model = post
    success_url = '/'
    # True will result in success_url
    def test_func(self):
        post = self.get_object()
        if self.request.user == post.author:
            # the left side check for the current user = self.request.user
            # the right side check for the post authoer = self.get_object().author
            return True
        return False
