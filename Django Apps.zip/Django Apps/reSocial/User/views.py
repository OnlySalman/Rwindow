from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import UserRegisterForm, UserUpdateForm, ProfileUpdateForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from friends.models import Frinds
from django.db.models import Q


def Accpeted(request, pk):
    Crruent = request.user.id
    Sender = pk
    # rType = Frinds.objects.raw('SELECT rType FROM friends_Frinds WHERE uFrom_id =%s AND uTo_id =%s ', (Sender, Crruent))
    friend = Frinds.objects.filter(Q(uFrom_id=Sender),Q(uTo_id=Crruent)).update(rType=2)
    return redirect('profile-Friends-Request')

def Rejected(request, pk):
    Crruent = request.user.id
    Sender = pk
    friend = Frinds.objects.filter(Q(uFrom_id=Sender),Q(uTo_id=Crruent))
    friend.delete()
    return redirect('profile-Friends-Request')

def register(request):
        if request.method == 'POST':
            form = UserRegisterForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('Homepage')
        form = UserRegisterForm()
        return render(request, 'User/register.html', {'form':form})


@login_required
def RequestRecived(request):
    Currnet = request.user.id
    users = User.objects.raw('SELECT * FROM auth_user WHERE id !=%s AND id IN ('' SELECT uFrom_id FROM friends_Frinds WHERE uTo_id =%s AND rType != 2'')', (Currnet, Currnet))
    return render(request, 'User/FriendRequested.html',{'users': users})


@login_required
def profile(request):
    uid = request.user.id
    users = User.objects.get(id=uid)
    return render(request, 'User/profile.html',{'users': users})

@login_required
def profileUpdate(request):
    if request.method == 'POST':
        u_form = UserUpdateForm(request.POST, instance=request.user)
        p_form = ProfileUpdateForm(request.POST,
                                   request.FILES,
                                   instance=request.user.profile)
        if u_form.is_valid() and p_form.is_valid():
            u_form.save()
            p_form.save()
            return redirect('profile-Edit')

    else:
        u_form = UserUpdateForm(instance=request.user)
        p_form = ProfileUpdateForm(instance=request.user.profile)

    context = {
        'u_form': u_form,
        'p_form': p_form
    }

    return render(request, 'User/profileEdit.html', context)
