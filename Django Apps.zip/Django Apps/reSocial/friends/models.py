from django.db import models
from django.contrib.auth.models import User

class Frinds(models.Model):
    uFrom = models.ForeignKey(User, on_delete=models.CASCADE, related_name="Sender")
    uTo = models.ForeignKey(User, on_delete=models.CASCADE, related_name="Reciver")
    rType = models.IntegerField()
    # 1 => Pending / 2 => Accepted / 3 => Rejected
