from .models import Blog
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse

def index(request):
    content = Blog.objects.all()
    context = {"Blog" : content}
    return render(request,"post/index.html",context)


def Remove(request,post_number):
    flashPost = Blog.objects.get(id=post_number)
    flashPost.delete()
    return HttpResponseRedirect(reverse('index'))
    # (reverse) search for a function in the name of the input.
    # if there was insted of index put "home" an error will occure

def Edit(request,post_number):
    task =  Blog.objects.filter(id=post_number).update(head=request.POST["title_"],body=request.POST["desc"])
    return HttpResponseRedirect(reverse('index'))

def Add(request):
    flashPost = Blog(head=request.POST['head'],body=request.POST['body'])
    flashPost.save()
    return HttpResponseRedirect('home')
