from django.urls import path

from . import views

urlpatterns = [
               path('home', views.index, name='index'),
               path('<int:post_number>/Remove', views.Remove, name='Remove'),
               path('<int:post_number>/Edit', views.Edit, name='Edit'),
               path('Add', views.Add, name='Add'),
               ]
