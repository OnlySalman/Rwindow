from django.db import models


class Uesr(models.Model):
    email = models.CharField(max_length=100)
    userName = models.CharField(max_length=15)

class userTask(models.Model):
    user = models.ForeignKey(Uesr, on_delete=models.CASCADE)
    Title = models.CharField(max_length=20);
    description = models.CharField(max_length=200)
    def __str__(self):
        return "Task is: ="+ self.Title + "," + "the description of the task is" + self.description

    #
    # question = models.ForeignKey(User, on_delete=models.CASCADE)
    # choice_text = models.CharField(max_length=200)
    # votes = models.IntegerField(default=0)
