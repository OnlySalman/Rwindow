from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from .models import Uesr, userTask
from django.urls import reverse
from django.contrib.auth.models import User

def starter(request):
    return render(request, 'Tasks/starter.html')

def index(request):
    return render(request, 'Tasks/index.html')

def Register(request):
    user = Uesr(email=request.POST["email_"], userName=request.POST["username_"])
    user.save()
    return render(request, 'Tasks/Mainpage.html',context)

def Check(request):
    user = Uesr.objects.all()
    context = {'Uesr': user}
    return render(request, 'Tasks/check.html',context)


def AddTask(request):
    task = Task(Title=request.POST["title"], description=request.POST["des"])
    task.save()
    return HttpResponseRedirect('index')

def Revmove(request,Task_id):
    task =  Task.objects.get(id=Task_id)
    task.delete()
    return HttpResponseRedirect('index')

def Edit(request,Task_id):
    task =  Task.objects.filter(id=Task_id).update(Title=request.POST["title_"],description=request.POST["desc"])
        # Other approch by the use of get
        # obj = Task.objects.get(pk=Task_id)
        # obj.Title = request.POST["title_"]
        # obj.description = request.POST['desc']
        # obj.save()
    return HttpResponseRedirect(reverse('index'))
