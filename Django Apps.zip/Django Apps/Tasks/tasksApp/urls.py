from django.urls import path

from . import views

urlpatterns = [
               path('starter', views.starter, name='starter'),
               path('index', views.index, name='index'),
               path('Register', views.Register, name='Register'),
               path('check', views.Check, name='index'),
               path('AddTask',views.AddTask,name='AddTask'),
               path('<int:Task_id>',views.Revmove,name='Complate'),
               path('Edit/<int:Task_id>',views.Edit,name='Edit')
               ]
