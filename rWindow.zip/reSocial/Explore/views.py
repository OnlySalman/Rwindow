from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib.auth.models import User
from django.views.generic.list import ListView
from friends.models import Frinds
# Create your views here.


def RequestForFriend(request,pk):
    Sender = User.objects.get(id=request.user.id)
    Reciver = User.objects.get(id=pk)

    req = Frinds(uFrom=Sender, uTo=Reciver, rType = 1)
    req.save()
    return redirect("explore-list")

class ExploreListView(ListView):
    # posts = post.objects.raw('SELECT * FROM Blog_post LEFT JOIN post_replay_pReplay  ON Blog_post.id = post_replay_pReplay.posted_id
    # WHERE author_id =%s OR author_id IN ('' SELECT uFrom_id FROM friends_Frinds WHERE uTo_id =%s AND rType=2 '') ORDER BY  date_posted DESC',(uid, uid))
    # posts = post.objects.raw('SELECT * FROM Blog_post WHERE author_id =%s AND Title in ("User","us","Users")', [uid])
    # model = User
    template_name = 'Explore/ExFriends.html'
    context_object_name = 'Exfriends'

    def get_queryset(self):
            Currnet = self.request.user.id
            model = User.objects.raw('SELECT * FROM auth_user WHERE id !=%s AND id NOT IN ('' SELECT uTo_id FROM friends_Frinds WHERE uFrom_id =%s UNION  SELECT uFrom_id  FROM friends_Frinds WHERE uTo_id =%s  '')', (Currnet, Currnet, Currnet))
            return model

    # string = ""
    # string += "Current user :"+ request.user.username
    # string += "Current user :"+ request.user.username
    # string += "<br>"
    # for i in x:
    #     string += " - USERNAME: " + i.username
    #     string += " - EMAIL: " + i.email
    #     string += "<br>"
    # return HttpResponse(string)
