from django.apps import AppConfig


class PostReplayConfig(AppConfig):
    name = 'post_replay'
