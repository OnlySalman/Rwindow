from django.contrib import admin
from .models import pReplay
admin.site.register(pReplay)
